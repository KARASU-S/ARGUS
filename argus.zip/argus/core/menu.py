from rich.console import Console
from rich.table import Table
from core.finding import Finding

def banner() -> str:
    return """
 █████╗ ██╗   ██╗████████╗ ██████╗ 
██╔══██╗██║   ██║╚══██╔══╝██╔═══██╗
███████║██║   ██║   ██║   ██║   ██║
██╔══██║██║   ██║   ██║   ██║   ██║
██║  ██║╚██████╔╝   ██║   ╚██████╔╝
╚═╝  ╚═╝ ╚═════╝    ╚═╝    ╚═════╝ 
                v0.2
"""

def show_menu() -> None:
    console = Console()
    console.print("""
1  — Port scan: FULL + fingerprint (stealth)
2  — Port scan: TOP-1000 + fingerprint (stealth)
3  — Port scan: ALL ports (stealth, no fingerprint)
4  — Port scan: FULL (aggressive)
5  — Port scan: TOP (aggressive)
─────────────────────────────
6  — DNS recon
7  — WHOIS recon
8  — crt.sh subdomains
9  — GitHub leaks
10 — Web recon
─────────────────────────────
S  — Subdomain brute-force
T  — Tech fingerprint
H  — Export HTML report
─────────────────────────────
A  — Run ALL recon
Q  — Analyze with AI
0  — Exit
""")

def show_ports(findings: list[Finding]) -> None:
    console = Console()
    table = Table(title="Открытые порты")
    table.add_column("Port", justify="right", style="cyan")
    table.add_column("Banner", style="green")
    
    for f in findings[:50]:
        banner_text = f.data.get("banner", "")
        table.add_row(str(f.data["port"]), banner_text[:100])
        
    console.print(table)