import httpx
import ollama
import asyncio
from rich.console import Console
from pathlib import Path

class AIEngine:
    def __init__(self, model: str = "qwen2.5:3b", host: str = "http://localhost:11434"):
        self.model = model
        self.host = host
        self.client = ollama.Client(host=host)
        prompt_path = Path(__file__).resolve().parent.parent / "ai" / "prompts" / "system_pentest.md"
        self.system_prompt = prompt_path.read_text(encoding="utf-8")

    def _check_ollama(self) -> bool:
        try:
            resp = httpx.get(f"{self.host}/api/tags", timeout=3)
            return resp.status_code == 200
        except Exception:
            return False

    def _format_findings(self, findings: list[dict]) -> str:
        if not findings:
            return "нет данных"
        
        if len(findings) <= 50:
            lines = [f"[{f['category']}] {f['module']} @ {f['target']}: {f['data']}" for f in findings]
        else:
            from collections import defaultdict
            grouped = defaultdict(list)
            for f in findings:
                grouped[f['module']].append(f)
            
            lines = []
            for mod, items in grouped.items():
                examples = [f['target'] for f in items[:5]]
                lines.append(f"[{mod}] count={len(items)}, примеры: {', '.join(examples)}")
        
        result = "\n".join(lines)
        if len(result) > 12000:
            result = result[:12000]
            last_newline = result.rfind('\n')
            if last_newline != -1:
                result = result[:last_newline]
        return result

    def analyze(self, findings: list[dict]) -> str:
        if not self._check_ollama():
            Console().print("[red]Ollama не запущена. Выполни: ollama serve && ollama pull qwen2.5:3b[/red]")
            return ""
        
        ctx = self._format_findings(findings)
        try:
            resp = self.client.chat(
                model=self.model,
                messages=[
                    {"role": "system", "content": self.system_prompt},
                    {"role": "user", "content": f"РЕЗУЛЬТАТЫ СКАНА:\n{ctx}\n\nЗАДАЧА:\nПроанализируй и выдай структурированный отчёт."},
                ],
                options={
                    "temperature": 0.2,
                    "num_ctx": 4096,
                    "num_predict": 1024,
                },
                stream=True,
            )
            full_text = ""
            for chunk in resp:
                piece = chunk['message']['content']
                print(piece, end="", flush=True)
                full_text += piece
            print()
            return full_text
        except Exception as e:
            Console().print(f"[red]Ошибка AI: {e}[/red]")
            return ""