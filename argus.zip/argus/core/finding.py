from dataclasses import dataclass, field, asdict
from datetime import datetime

@dataclass
class Finding:
    module: str
    target: str
    category: str
    severity: str = "info"
    data: dict = field(default_factory=dict)

    def to_dict(self) -> dict:
        d = asdict(self)
        d["ts"] = datetime.utcnow().isoformat()
        return d