import sqlite3
import json
import time
from pathlib import Path

CACHE_DB = "reports/.argus_cache.db"
CACHE_TTL_SECONDS = 86400

class Cache:
    def __init__(self, db_path: str = CACHE_DB):
        self.db_path = db_path
        Path(self.db_path).parent.mkdir(parents=True, exist_ok=True)
        self._init_db()

    def _init_db(self) -> None:
        conn = sqlite3.connect(self.db_path)
        conn.execute("""
            CREATE TABLE IF NOT EXISTS cache (
                key TEXT PRIMARY KEY,
                ts INTEGER NOT NULL,
                data TEXT NOT NULL
            )
        """)
        conn.close()

    def get(self, key: str) -> list[dict] | None:
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            cursor.execute("SELECT ts, data FROM cache WHERE key = ?", (key,))
            row = cursor.fetchone()
            if row:
                ts, data = row
                if int(time.time()) - ts > CACHE_TTL_SECONDS:
                    cursor.execute("DELETE FROM cache WHERE key = ?", (key,))
                    conn.commit()
                    conn.close()
                    return None
                conn.close()
                return json.loads(data)
            conn.close()
            return None
        except Exception:
            return None

    def set(self, key: str, findings: list[dict]) -> None:
        try:
            conn = sqlite3.connect(self.db_path)
            ts = int(time.time())
            data = json.dumps(findings, ensure_ascii=False)
            conn.execute(
                "INSERT OR REPLACE INTO cache (key, ts, data) VALUES (?, ?, ?)",
                (key, ts, data)
            )
            conn.commit()
            conn.close()
        except Exception:
            pass

    def clear(self) -> None:
        try:
            conn = sqlite3.connect(self.db_path)
            conn.execute("DELETE FROM cache")
            conn.commit()
            conn.close()
        except Exception:
            pass