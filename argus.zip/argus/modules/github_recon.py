import asyncio
import httpx
from core.finding import Finding

async def _run_async(domain: str) -> list[Finding]:
    queries = [
        f'"{domain}" password',
        f'"{domain}" api_key',
        f'"{domain}" secret',
        f'"{domain}" .env'
    ]
    findings = []
    async with httpx.AsyncClient() as client:
        for q in queries:
            try:
                resp = await client.get(
                    "https://api.github.com/search/code",
                    params={"q": q, "per_page": 5},
                    timeout=20
                )
                if resp.status_code in (403, 429):
                    continue
                resp.raise_for_status()
                data = resp.json()
                if data.get("items"):
                    hits = [{"repo": item["repository"]["full_name"], "path": item["path"], "url": item["html_url"]} for item in data["items"]]
                    findings.append(Finding(
                        module="github",
                        target=domain,
                        category="osint",
                        severity="high",
                        data={"query": q, "hits": hits}
                    ))
            except Exception:
                pass
    return findings

def run(domain: str) -> list[Finding]:
    return asyncio.run(_run_async(domain))