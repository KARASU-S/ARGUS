import asyncio
import httpx
import re
import yaml
from core.finding import Finding

SIGNATURES_PATH = "data/tech_signatures.yaml"

def _load_signatures() -> dict:
    try:
        with open(SIGNATURES_PATH, "r", encoding="utf-8") as f:
            return yaml.safe_load(f) or {}
    except Exception:
        return {}

async def _run_async(target: str) -> list[Finding]:
    if not target.startswith("http"):
        target = f"https://{target}"
    try:
        async with httpx.AsyncClient(verify=False) as client:
            resp = await client.get(target, timeout=15, follow_redirects=True)
            signatures = _load_signatures()
            found_techs = []
            
            headers_lower = {k.lower(): v for k, v in resp.headers.items()}
            html_text = resp.text

            for tech_name, sigs in signatures.items():
                found = False
                for hdr_key, hdr_regex in sigs.get("headers", {}).items():
                    if hdr_key in headers_lower:
                        if re.search(hdr_regex, headers_lower[hdr_key], re.I):
                            found = True
                            break
                if not found:
                    for html_regex in sigs.get("html", []):
                        if re.search(html_regex, html_text, re.I):
                            found = True
                            break
                if found:
                    found_techs.append(tech_name)
            
            found_techs.sort()
            return [Finding(
                module="tech_fingerprint",
                target=target,
                category="web",
                data={"technologies": found_techs, "count": len(found_techs)}
            )]
    except Exception as e:
        return [Finding(
            module="tech_fingerprint",
            target=target,
            category="web",
            data={"error": str(e)}
        )]

def run(target: str) -> list[Finding]:
    return asyncio.run(_run_async(target))