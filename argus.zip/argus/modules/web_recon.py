import asyncio
import httpx
import re
from core.finding import Finding

SEC_HEADERS = [
    "strict-transport-security",
    "content-security-policy",
    "x-frame-options",
    "x-content-type-options",
    "referrer-policy",
    "permissions-policy"
]

def _title(html: str) -> str:
    match = re.search(r'<title[^>]*>(.*?)</title>', html, re.I | re.S)
    if match:
        return match.group(1).strip()[:120]
    return ""

async def _run_async(target: str) -> list[Finding]:
    findings = []
    if not target.startswith("http"):
        target = f"https://{target}"
    
    try:
        async with httpx.AsyncClient() as client:
            resp = await client.get(target, timeout=15, follow_redirects=True, verify=False)
            headers = resp.headers
            
            missing = [h for h in SEC_HEADERS if h not in headers]
            
            data = {
                "status": resp.status_code,
                "server": headers.get("server"),
                "powered_by": headers.get("x-powered-by"),
                "missing_security_headers": missing,
                "title": _title(resp.text)
            }
            findings.append(Finding(
                module="web",
                target=target,
                category="web",
                data=data
            ))
            
            try:
                robots_url = f"{target.rstrip('/')}/robots.txt"
                r_resp = await client.get(robots_url, timeout=8, follow_redirects=True, verify=False)
                if r_resp.status_code == 200:
                    findings.append(Finding(
                        module="web",
                        target=robots_url,
                        category="web",
                        data={"robots": r_resp.text[:2000]}
                    ))
            except Exception:
                pass
                
    except Exception as e:
        findings.append(Finding(
            module="web",
            target=target,
            category="web",
            data={"error": str(e)}
        ))
        
    return findings

def run(target: str) -> list[Finding]:
    return asyncio.run(_run_async(target))