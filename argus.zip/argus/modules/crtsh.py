import asyncio
import httpx
from core.finding import Finding

async def _run_async(domain: str) -> list[Finding]:
    try:
        async with httpx.AsyncClient() as client:
            resp = await client.get(f"https://crt.sh/?q=%25.{domain}&output=json", timeout=30)
            resp.raise_for_status()
            data = resp.json()
            subdomains = set()
            for item in data:
                names = item.get("name_value", "").split("\n")
                for name in names:
                    if name:
                        subdomains.add(name)
            
            sorted_subs = sorted(list(subdomains))
            return [Finding(
                module="crtsh",
                target=domain,
                category="osint",
                data={"subdomains": sorted_subs, "count": len(sorted_subs)}
            )]
    except Exception as e:
        return [Finding(
            module="crtsh",
            target=domain,
            category="osint",
            data={"error": str(e)}
        )]

def run(domain: str) -> list[Finding]:
    return asyncio.run(_run_async(domain))