import asyncio
import dns.resolver
import tldextract
from core.finding import Finding

WORDLIST_PATH = "data/subdomains.txt"
WILDCARD_PROBE = "argus-wildcard-probe-1337"

async def _resolve(subdomain: str) -> str | None:
    try:
        answers = dns.resolver.resolve(subdomain, "A", lifetime=3)
        return str(answers[0])
    except Exception:
        return None

async def _detect_wildcard(domain: str) -> str | None:
    return await _resolve(f"{WILDCARD_PROBE}.{domain}")

def _load_wordlist() -> list[str]:
    words = []
    try:
        with open(WORDLIST_PATH, "r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if line and not line.startswith("#"):
                    words.append(line)
    except Exception:
        pass
    return words

async def _run_async(domain: str, concurrency: int = 50) -> list[Finding]:
    ext = tldextract.extract(domain)
    root_domain = f"{ext.domain}.{ext.suffix}" if ext.suffix else domain
    wordlist = _load_wordlist()
    wildcard_ip = await _detect_wildcard(root_domain)
    results = []
    sem = asyncio.Semaphore(concurrency)

    async def worker(word: str):
        async with sem:
            ip = await _resolve(f"{word}.{root_domain}")
            if ip and ip != wildcard_ip:
                results.append({"name": f"{word}.{root_domain}", "ip": ip})

    tasks = [worker(w) for w in wordlist]
    await asyncio.gather(*tasks)

    results.sort(key=lambda x: x["name"])
    return [Finding(
        module="subdomain_brute",
        target=domain,
        category="osint",
        data={
            "subdomains": results,
            "count": len(results),
            "wildcard": wildcard_ip
        }
    )]

def run(domain: str) -> list[Finding]:
    return asyncio.run(_run_async(domain))