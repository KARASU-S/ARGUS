import whois
from core.finding import Finding

def run(domain: str) -> list[Finding]:
    try:
        w = whois.whois(domain)
        data = {k: str(v) for k, v in dict(w).items() if v}
        return [Finding(module="whois", target=domain, category="osint", data=data)]
    except Exception as e:
        return [Finding(module="whois", target=domain, category="osint", data={"error": str(e)})]