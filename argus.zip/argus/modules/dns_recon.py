import dns.resolver
from core.finding import Finding

def run(domain: str) -> list[Finding]:
    findings = []
    record_types = ["A", "AAAA", "MX", "TXT", "NS", "SOA", "CNAME"]
    for rt in record_types:
        try:
            answers = dns.resolver.resolve(domain, rt, lifetime=5)
            values = [str(rdata) for rdata in answers]
            findings.append(Finding(
                module="dns",
                target=domain,
                category="dns",
                data={"type": rt, "values": values}
            ))
        except Exception:
            pass
    
    try:
        dmarc_domain = f"_dmarc.{domain}"
        answers = dns.resolver.resolve(dmarc_domain, "TXT", lifetime=5)
        values = [str(rdata) for rdata in answers]
        findings.append(Finding(
            module="dns",
            target=dmarc_domain,
            category="dns",
            data={"type": "TXT", "values": values}
        ))
    except Exception:
        pass
        
    return findings