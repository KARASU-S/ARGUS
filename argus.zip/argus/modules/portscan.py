import asyncio
import ssl
from core.finding import Finding

TOP_PORTS = [21,22,23,25,53,80,110,111,135,139,143,443,445,993,995,
             1723,3306,3389,5900,8080,8443,8000,8888,9000,27017,
             6379,5432,1521,1433,5000]

MODES = {
    "1": ("Full scan + fingerprint (stealth)", list(range(1,65536)), False, True),
    "2": ("Top-1000 + fingerprint (stealth)", TOP_PORTS, False, True),
    "3": ("Full scan (all ports, stealth)",   list(range(1,65536)), False, False),
    "4": ("Aggressive full + fingerprint",    list(range(1,65536)), True,  True),
    "5": ("Aggressive top ports",             TOP_PORTS, True,  False),
}

async def _tls_info(host: str, port: int) -> dict:
    writer = None
    try:
        context = ssl.create_default_context()
        context.check_hostname = False
        context.verify_mode = ssl.CERT_NONE
        reader, writer = await asyncio.open_connection(host, port, ssl=context)
        cipher = writer.get_extra_info("cipher")
        return {
            "cipher": cipher[0] if cipher else None,
            "cert_present": True
        }
    except Exception:
        return {}
    finally:
        if writer is not None:
            try:
                writer.close()
                await writer.wait_closed()
            except Exception:
                pass

async def scan_port(host: str, port: int, timeout: float = 1.5, banner: bool = True) -> dict | None:
    writer = None
    try:
        reader, writer = await asyncio.wait_for(
            asyncio.open_connection(host, port),
            timeout=timeout
        )
        result = {"port": port, "state": "open", "banner": ""}

        if banner:
            try:
                writer.write(b"\r\n")
                await asyncio.wait_for(writer.drain(), timeout=1.5)
                data = await asyncio.wait_for(reader.read(1024), timeout=1.5)
                result["banner"] = data.decode(errors="ignore")[:200].strip()
            except Exception:
                pass

            if port in (443, 8443, 993, 995):
                result["tls"] = await _tls_info(host, port)

        return result
    except Exception:
        return None
    finally:
        if writer is not None:
            try:
                writer.close()
                await writer.wait_closed()
            except Exception:
                pass

async def run_scan(host: str, ports: list[int], concurrency: int = 200, aggressive: bool = False, fingerprint: bool = True) -> list[Finding]:
    sem = asyncio.Semaphore(concurrency if aggressive else 50)
    findings = []
    
    async def worker(p: int):
        async with sem:
            res = await scan_port(host, p, banner=fingerprint)
            if res:
                findings.append(Finding(
                    module="portscan",
                    target=f"{host}:{p}",
                    category="port",
                    data=res
                ))
            if not aggressive:
                await asyncio.sleep(0.01)
                
    tasks = [worker(p) for p in ports]
    await asyncio.gather(*tasks)
    
    findings.sort(key=lambda x: x.data["port"])
    return findings

def parse_ports(arg: str) -> list[int]:
    result = []
    for part in arg.split(","):
        if "-" in part:
            start, end = map(int, part.split("-"))
            result.extend(range(start, end + 1))
        else:
            result.append(int(part))
    return result