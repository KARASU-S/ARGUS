import asyncio
import json
import sys
from pathlib import Path
from datetime import datetime
import typer
from rich.prompt import Prompt
from rich.console import Console

from core.finding import Finding
from core.menu import banner, show_menu, show_ports
from core.ai_engine import AIEngine
from core.cache import Cache
import modules.portscan as portscan
import modules.dns_recon as dns_recon
import modules.whois_recon as whois_recon
import modules.crtsh as crtsh
import modules.github_recon as github_recon
import modules.web_recon as web_recon
from modules import subdomain_brute, tech_fingerprint
from report import html_report

app = typer.Typer()

def save_report(target: str, findings: list[Finding]) -> None:
    reports_dir = Path("reports")
    reports_dir.mkdir(exist_ok=True)
    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    filename = reports_dir / f"{target}_{ts}.json"
    data = [f.to_dict() for f in findings]
    with open(filename, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)
    console = Console()
    console.print(f"[green]Отчёт сохранён: {filename}[/green]")

@app.command()
def main(
    target: str = typer.Option(None, "--target", "-t", help="Цель (domain/ip)"),
    mode: str = typer.Option(None, "--mode", "-m", help="Режим: 1-10, a, s, t, q"),
    output: str = typer.Option(None, "--output", "-o", help="Путь для HTML-отчёта"),
    no_ai: bool = typer.Option(False, "--no-ai", help="Не запускать AI даже при mode=q"),
    no_cache: bool = typer.Option(False, "--no-cache", help="Игнорировать кэш"),
) -> None:
    console = Console()
    cache = Cache()

    if not target:
        console.print(banner())
        target = Prompt.ask("Укажи цель")
        if not target:
            return
        
        findings: list[Finding] = []
        ai: AIEngine | None = None
        
        while True:
            show_menu()
            choice = Prompt.ask("Выбор").strip().lower()
            if choice == "0":
                break
            
            try:
                if choice in ["1", "2", "3", "4", "5"]:
                    cache_key = f"portscan:{target}:{choice}"
                    if not no_cache and (cached := cache.get(cache_key)):
                        console.print(f"[dim]Из кэша: {cache_key}[/dim]")
                        findings.extend([Finding(**{k: v for k, v in c.items() if k != "ts"}) for c in cached])
                    else:
                        label, ports, aggressive, fingerprint = portscan.MODES[choice]
                        console.print(f"[yellow]Запуск: {label}[/yellow]")
                        res = asyncio.run(portscan.run_scan(target, ports, aggressive=aggressive, fingerprint=fingerprint))
                        findings.extend(res)
                        cache.set(cache_key, [f.to_dict() for f in res])
                        show_ports(res)
                elif choice == "6":
                    cache_key = f"dns:{target}:default"
                    if not no_cache and (cached := cache.get(cache_key)):
                        console.print(f"[dim]Из кэша: {cache_key}[/dim]")
                        findings.extend([Finding(**{k: v for k, v in c.items() if k != "ts"}) for c in cached])
                    else:
                        res = dns_recon.run(target)
                        findings.extend(res)
                        cache.set(cache_key, [f.to_dict() for f in res])
                        console.print(f"[green]DNS recon завершён. Найдено: {len(res)}[/green]")
                elif choice == "7":
                    cache_key = f"whois:{target}:default"
                    if not no_cache and (cached := cache.get(cache_key)):
                        console.print(f"[dim]Из кэша: {cache_key}[/dim]")
                        findings.extend([Finding(**{k: v for k, v in c.items() if k != "ts"}) for c in cached])
                    else:
                        res = whois_recon.run(target)
                        findings.extend(res)
                        cache.set(cache_key, [f.to_dict() for f in res])
                        console.print("[green]WHOIS recon завершён.[/green]")
                elif choice == "8":
                    cache_key = f"crtsh:{target}:default"
                    if not no_cache and (cached := cache.get(cache_key)):
                        console.print(f"[dim]Из кэша: {cache_key}[/dim]")
                        findings.extend([Finding(**{k: v for k, v in c.items() if k != "ts"}) for c in cached])
                    else:
                        res = crtsh.run(target)
                        findings.extend(res)
                        cache.set(cache_key, [f.to_dict() for f in res])
                        console.print("[green]crt.sh завершён.[/green]")
                elif choice == "9":
                    cache_key = f"github:{target}:default"
                    if not no_cache and (cached := cache.get(cache_key)):
                        console.print(f"[dim]Из кэша: {cache_key}[/dim]")
                        findings.extend([Finding(**{k: v for k, v in c.items() if k != "ts"}) for c in cached])
                    else:
                        res = github_recon.run(target)
                        findings.extend(res)
                        cache.set(cache_key, [f.to_dict() for f in res])
                        console.print(f"[green]GitHub recon завершён. Найдено: {len(res)}[/green]")
                elif choice == "10":
                    cache_key = f"web:{target}:default"
                    if not no_cache and (cached := cache.get(cache_key)):
                        console.print(f"[dim]Из кэша: {cache_key}[/dim]")
                        findings.extend([Finding(**{k: v for k, v in c.items() if k != "ts"}) for c in cached])
                    else:
                        res = web_recon.run(target)
                        findings.extend(res)
                        cache.set(cache_key, [f.to_dict() for f in res])
                        console.print(f"[green]Web recon завершён. Найдено: {len(res)}[/green]")
                elif choice == "s":
                    cache_key = f"subdomain_brute:{target}:default"
                    if not no_cache and (cached := cache.get(cache_key)):
                        console.print(f"[dim]Из кэша: {cache_key}[/dim]")
                        findings.extend([Finding(**{k: v for k, v in c.items() if k != "ts"}) for c in cached])
                    else:
                        res = subdomain_brute.run(target)
                        findings.extend(res)
                        cache.set(cache_key, [f.to_dict() for f in res])
                        console.print(f"[green]Subdomain brute завершён. Найдено: {len(res)}[/green]")
                elif choice == "t":
                    cache_key = f"tech_fingerprint:{target}:default"
                    if not no_cache and (cached := cache.get(cache_key)):
                        console.print(f"[dim]Из кэша: {cache_key}[/dim]")
                        findings.extend([Finding(**{k: v for k, v in c.items() if k != "ts"}) for c in cached])
                    else:
                        res = tech_fingerprint.run(target)
                        findings.extend(res)
                        cache.set(cache_key, [f.to_dict() for f in res])
                        console.print(f"[green]Tech fingerprint завершён. Найдено: {len(res)}[/green]")
                elif choice == "h":
                    path = html_report.save(target, findings)
                    console.print(f"[green]HTML: {path}[/green]")
                elif choice == "a":
                    console.print("[yellow]Запуск ALL recon...[/yellow]")
                    cache_key_ps = f"portscan:{target}:2"
                    if not no_cache and (cached_ps := cache.get(cache_key_ps)):
                        console.print(f"[dim]Из кэша: {cache_key_ps}[/dim]")
                        findings.extend([Finding(**{k: v for k, v in c.items() if k != "ts"}) for c in cached_ps])
                    else:
                        res = asyncio.run(portscan.run_scan(target, portscan.TOP_PORTS, aggressive=False, fingerprint=True))
                        findings.extend(res)
                        cache.set(cache_key_ps, [f.to_dict() for f in res])
                    
                    for mod_name, mod_func, c_key_base in [
                        ("dns", dns_recon.run, "dns"),
                        ("whois", whois_recon.run, "whois"),
                        ("crtsh", crtsh.run, "crtsh"),
                        ("github", github_recon.run, "github"),
                        ("web", web_recon.run, "web"),
                        ("subdomain_brute", subdomain_brute.run, "subdomain_brute"),
                        ("tech_fingerprint", tech_fingerprint.run, "tech_fingerprint")
                    ]:
                        c_key = f"{c_key_base}:{target}:default"
                        if not no_cache and (cached := cache.get(c_key)):
                            console.print(f"[dim]Из кэша: {c_key}[/dim]")
                            findings.extend([Finding(**{k: v for k, v in c.items() if k != "ts"}) for c in cached])
                            continue
                        res = mod_func(target)
                        findings.extend(res)
                        cache.set(c_key, [f.to_dict() for f in res])
                    console.print("[green]ALL recon завершён.[/green]")
                elif choice == "q":
                    if not findings:
                        console.print("[red]Нет данных для анализа. Сначала проведите разведку.[/red]")
                        continue
                    ai = ai or AIEngine()
                    ai.analyze([f.to_dict() for f in findings])
                    save_report(target, findings)
                else:
                    console.print("[red]Неизвестный пункт[/red]")
            except Exception as e:
                console.print(f"[red]Ошибка в модуле: {e}[/red]")
    else:
        findings: list[Finding] = []
        try:
            m = mode or "a"
            if m in ["1", "2", "3", "4", "5"]:
                cache_key = f"portscan:{target}:{m}"
                if not no_cache and (cached := cache.get(cache_key)):
                    findings.extend([Finding(**{k: v for k, v in c.items() if k != "ts"}) for c in cached])
                else:
                    label, ports, aggressive, fingerprint = portscan.MODES[m]
                    res = asyncio.run(portscan.run_scan(target, ports, aggressive=aggressive, fingerprint=fingerprint))
                    findings.extend(res)
                    cache.set(cache_key, [f.to_dict() for f in res])
            elif m == "6":
                cache_key = f"dns:{target}:default"
                if not no_cache and (cached := cache.get(cache_key)):
                    findings.extend([Finding(**{k: v for k, v in c.items() if k != "ts"}) for c in cached])
                else:
                    res = dns_recon.run(target)
                    findings.extend(res)
                    cache.set(cache_key, [f.to_dict() for f in res])
            elif m == "7":
                cache_key = f"whois:{target}:default"
                if not no_cache and (cached := cache.get(cache_key)):
                    findings.extend([Finding(**{k: v for k, v in c.items() if k != "ts"}) for c in cached])
                else:
                    res = whois_recon.run(target)
                    findings.extend(res)
                    cache.set(cache_key, [f.to_dict() for f in res])
            elif m == "8":
                cache_key = f"crtsh:{target}:default"
                if not no_cache and (cached := cache.get(cache_key)):
                    findings.extend([Finding(**{k: v for k, v in c.items() if k != "ts"}) for c in cached])
                else:
                    res = crtsh.run(target)
                    findings.extend(res)
                    cache.set(cache_key, [f.to_dict() for f in res])
            elif m == "9":
                cache_key = f"github:{target}:default"
                if not no_cache and (cached := cache.get(cache_key)):
                    findings.extend([Finding(**{k: v for k, v in c.items() if k != "ts"}) for c in cached])
                else:
                    res = github_recon.run(target)
                    findings.extend(res)
                    cache.set(cache_key, [f.to_dict() for f in res])
            elif m == "10":
                cache_key = f"web:{target}:default"
                if not no_cache and (cached := cache.get(cache_key)):
                    findings.extend([Finding(**{k: v for k, v in c.items() if k != "ts"}) for c in cached])
                else:
                    res = web_recon.run(target)
                    findings.extend(res)
                    cache.set(cache_key, [f.to_dict() for f in res])
            elif m == "s":
                cache_key = f"subdomain_brute:{target}:default"
                if not no_cache and (cached := cache.get(cache_key)):
                    findings.extend([Finding(**{k: v for k, v in c.items() if k != "ts"}) for c in cached])
                else:
                    res = subdomain_brute.run(target)
                    findings.extend(res)
                    cache.set(cache_key, [f.to_dict() for f in res])
            elif m == "t":
                cache_key = f"tech_fingerprint:{target}:default"
                if not no_cache and (cached := cache.get(cache_key)):
                    findings.extend([Finding(**{k: v for k, v in c.items() if k != "ts"}) for c in cached])
                else:
                    res = tech_fingerprint.run(target)
                    findings.extend(res)
                    cache.set(cache_key, [f.to_dict() for f in res])
            elif m == "a":
                cache_key_ps = f"portscan:{target}:2"
                if not no_cache and (cached_ps := cache.get(cache_key_ps)):
                    findings.extend([Finding(**{k: v for k, v in c.items() if k != "ts"}) for c in cached_ps])
                else:
                    res = asyncio.run(portscan.run_scan(target, portscan.TOP_PORTS, aggressive=False, fingerprint=True))
                    findings.extend(res)
                    cache.set(cache_key_ps, [f.to_dict() for f in res])
                
                for mod_name, mod_func, c_key_base in [
                    ("dns", dns_recon.run, "dns"),
                    ("whois", whois_recon.run, "whois"),
                    ("crtsh", crtsh.run, "crtsh"),
                    ("github", github_recon.run, "github"),
                    ("web", web_recon.run, "web"),
                    ("subdomain_brute", subdomain_brute.run, "subdomain_brute"),
                    ("tech_fingerprint", tech_fingerprint.run, "tech_fingerprint")
                ]:
                    c_key = f"{c_key_base}:{target}:default"
                    if not no_cache and (cached := cache.get(c_key)):
                        findings.extend([Finding(**{k: v for k, v in c.items() if k != "ts"}) for c in cached])
                    else:
                        res = mod_func(target)
                        findings.extend(res)
                        cache.set(c_key, [f.to_dict() for f in res])
            elif m == "q":
                cache_keys = [
                    f"portscan:{target}:1", f"portscan:{target}:2", f"portscan:{target}:3",
                    f"portscan:{target}:4", f"portscan:{target}:5",
                    f"dns:{target}:default", f"whois:{target}:default",
                    f"crtsh:{target}:default", f"github:{target}:default",
                    f"web:{target}:default", f"subdomain_brute:{target}:default",
                    f"tech_fingerprint:{target}:default",
                ]
                for ck in cache_keys:
                    cached = cache.get(ck)
                    if cached:
                        findings.extend([Finding(**{k: v for k, v in c.items() if k != "ts"}) for c in cached])
                if not findings:
                    console.print("[red]Нет данных в кэше. Сначала выполните разведку.[/red]")
                    return
            
            save_report(target, findings)
            if output:
                path = html_report.save(target, findings)
                console.print(f"[green]HTML: {path}[/green]")
            if m == "q" and not no_ai and findings:
                ai = AIEngine()
                ai.analyze([f.to_dict() for f in findings])
        except Exception as e:
            console.print(f"[red]Ошибка: {e}[/red]")

if __name__ == "__main__":
    app()